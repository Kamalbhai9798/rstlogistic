import Navigation from "@/components/navigation";
import HeroSection from "@/components/hero-section";
import ServicesSection from "@/components/services-section";
import BookingSystem from "@/components/booking-system";
import FleetGallery from "@/components/fleet-gallery";
import FounderSection from "@/components/founder-section";
import WhyChooseUs from "@/components/why-choose-us";
import ContactSection from "@/components/contact-section";
import Footer from "@/components/footer";

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      <HeroSection />
      <ServicesSection />
      <BookingSystem />
      <FleetGallery />
      <FounderSection />
      <WhyChooseUs />
      <ContactSection />
      <Footer />
    </div>
  );
}
