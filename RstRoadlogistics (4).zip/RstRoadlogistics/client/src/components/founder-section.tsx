export default function FounderSection() {
  const achievements = [
    { number: "15+", label: "Years Experience" },
    { number: "500+", label: "Happy Clients" },
    { number: "50+", label: "Fleet Vehicles" },
    { number: "24/7", label: "Service Support" }
  ];

  return (
    <section id="founder" className="py-20 bg-gray-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Meet Our Founder</h2>
          <p className="text-xl text-gray-600">The visionary behind RST ROADLINES</p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <img
              src="https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=600"
              alt="RANJEET MAHTO - Founder"
              className="rounded-2xl shadow-xl w-full max-w-md mx-auto"
            />
          </div>
          <div>
            <h3 className="text-3xl font-bold text-gray-900 mb-6">RANJEET MAHTO</h3>
            <p className="text-lg text-gray-600 mb-6">
              With over 15 years of experience in the logistics and transportation industry, Ranjeet Mahto founded RST ROADLINES with a vision to provide reliable, efficient, and affordable cargo services across West Bengal.
            </p>
            <p className="text-lg text-gray-600 mb-6">
              Starting from a single truck operation, Ranjeet's dedication to customer satisfaction and his deep understanding of the logistics challenges in West Bengal have helped RST ROADLINES grow into a trusted name in cargo transportation.
            </p>
            <p className="text-lg text-gray-600 mb-8">
              His commitment to modernizing the cargo industry with GPS tracking, professional drivers, and customer-centric services has set new standards for reliability and transparency in the region.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {achievements.map((achievement, index) => (
                <div key={index} className="bg-white p-6 rounded-xl shadow-lg">
                  <div className="text-3xl font-bold text-primary mb-2">{achievement.number}</div>
                  <div className="text-gray-600">{achievement.label}</div>
                </div>
              ))}
            </div>

            <blockquote className="mt-8 p-6 bg-white rounded-xl shadow-lg border-l-4 border-primary">
              <p className="text-lg italic text-gray-700 mb-4">
                "Our mission is simple: to make cargo transportation in West Bengal as reliable and transparent as possible. Every shipment is a promise we keep to our customers."
              </p>
              <cite className="text-primary font-semibold">- Ranjeet Mahto, Founder & CEO</cite>
            </blockquote>
          </div>
        </div>
      </div>
    </section>
  );
}
