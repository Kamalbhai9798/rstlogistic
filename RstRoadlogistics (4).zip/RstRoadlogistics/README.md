# RST ROADLINES - Cargo Transportation Platform

A professional cargo services website for RST ROADLINES, providing truck and mini truck transportation services across West Bengal, India.

## 🚛 About

RST ROADLINES is a cargo transportation company founded by **RANJEET MAHTO**, specializing in reliable truck and mini truck services throughout West Bengal. We provide efficient cargo transportation solutions with real-time tracking and competitive pricing.

## 📍 Service Areas

- Kolkata
- Howrah
- Durgapur
- Asansol
- Siliguri
- Malda
- Bankura
- Burdwan
- Jalpaiguri
- Krishnanagar
- Raiganj
- And more cities across West Bengal

## 🛠️ Features

- **Online Booking System**: Complete booking form with real-time fare calculation
- **Service Selection**: Choose between full truck (up to 32 tons) and mini truck (up to 3 tons) services
- **Contact Integration**: Multiple contact options including phone, WhatsApp, and email
- **Responsive Design**: Professional, mobile-friendly interface
- **Founder Information**: About the company founder and achievements
- **Fleet Gallery**: Showcase of company vehicles and services

## 📋 Services

### Full Truck Services
- Capacity: Up to 32 tons
- GPS tracking included
- Insurance coverage
- Professional drivers
- Starting from ₹15/km

### Mini Truck Services
- Capacity: Up to 3 tons
- Quick city deliveries
- Fuel efficient
- Same day service
- Starting from ₹8/km

## 📞 Contact Information

- **Address**: ADHYA SHRADYA GHAT ROAD, HOWRAH 700007, West Bengal, India
- **Phone**: +91 9163333798
- **WhatsApp**: +91 7003643774
- **Email**: info@rstroadlines.com
- **Business Hours**: Monday - Saturday: 6:00 AM - 10:00 PM, Sunday: 8:00 AM - 8:00 PM

## 🚀 Technology Stack

### Frontend
- React 18 with TypeScript
- Tailwind CSS for styling
- shadcn/ui component library
- Wouter for routing
- TanStack Query for data fetching
- React Hook Form with Zod validation

### Backend
- Node.js with Express
- TypeScript
- In-memory storage (MemStorage)
- RESTful API architecture

### Development Tools
- Vite for build tooling
- ESLint for code quality
- PostCSS for CSS processing

## 📁 Project Structure

```
├── client/             # Frontend React application
│   ├── src/
│   │   ├── components/ # UI components
│   │   ├── pages/      # Page components
│   │   ├── lib/        # Utility functions
│   │   └── hooks/      # Custom React hooks
├── server/             # Backend Express application
│   ├── index.ts        # Server entry point
│   ├── routes.ts       # API routes
│   └── storage.ts      # Data storage layer
├── shared/             # Shared types and schemas
│   └── schema.ts       # Database schemas and types
└── README.md
```

## 🔧 Development Setup

1. Clone the repository:
```bash
git clone <repository-url>
cd rst-roadlines
```

2. Install dependencies:
```bash
npm install
```

3. Start development server:
```bash
npm run dev
```

4. Open your browser and navigate to `http://localhost:5000`

## 📄 API Endpoints

- `POST /api/bookings` - Create new booking
- `GET /api/bookings` - Get all bookings
- `GET /api/bookings/:id` - Get specific booking
- `PATCH /api/bookings/:id/status` - Update booking status
- `POST /api/contacts` - Submit contact form
- `POST /api/calculate-fare` - Calculate transportation fare

## 🎯 Key Features

- **Real-time Fare Calculation**: Automatic fare estimation based on service type and weight
- **WhatsApp Integration**: Direct WhatsApp contact for quick bookings
- **Responsive Design**: Works seamlessly on desktop and mobile devices
- **Professional UI**: Clean, modern design with smooth animations
- **Form Validation**: Comprehensive input validation for all forms
- **Toast Notifications**: User-friendly feedback for all actions

## 👨‍💼 About the Founder

**RANJEET MAHTO** - Founder & CEO of RST ROADLINES

With over 15 years of experience in logistics and transportation, Ranjeet Mahto has built RST ROADLINES into a trusted name for cargo services across West Bengal. His commitment to reliability, transparency, and customer satisfaction has set new standards in the regional transportation industry.

## 📜 License

This project is proprietary software owned by RST ROADLINES.

## 🤝 Support

For support, email info@rstroadlines.com or call +91 9163333798

---

**RST ROADLINES** - Your trusted partner for reliable cargo transportation across West Bengal.