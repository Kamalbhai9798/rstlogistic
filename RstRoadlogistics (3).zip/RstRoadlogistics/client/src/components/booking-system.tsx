import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { MapPin, Calendar, Clock, Truck, Weight, Package, User, Phone, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { insertBookingSchema, type InsertBooking } from "@shared/schema";

export default function BookingSystem() {
  const [estimatedFare, setEstimatedFare] = useState(0);
  const { toast } = useToast();

  const form = useForm<InsertBooking>({
    resolver: zodResolver(insertBookingSchema),
    defaultValues: {
      pickupLocation: "",
      deliveryLocation: "",
      pickupDate: new Date().toISOString().split('T')[0],
      pickupTime: "",
      serviceType: "",
      weight: "0",
      cargoDescription: "",
      estimatedFare: 0,
      contactName: "",
      contactPhone: ""
    }
  });

  const createBookingMutation = useMutation({
    mutationFn: async (data: InsertBooking) => {
      const response = await apiRequest("POST", "/api/bookings", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Booking Submitted Successfully!",
        description: "We'll contact you shortly to confirm your booking details.",
      });
      form.reset();
      setEstimatedFare(0);
    },
    onError: () => {
      toast({
        title: "Booking Failed",
        description: "Please check your information and try again.",
        variant: "destructive",
      });
    }
  });

  const calculateFare = async (serviceType: string, weight: string) => {
    if (!serviceType || !weight) return;
    
    try {
      const response = await apiRequest("POST", "/api/calculate-fare", {
        serviceType,
        weight: parseFloat(weight) || 0,
        distance: 50 // Default distance for estimation
      });
      const data = await response.json();
      setEstimatedFare(data.estimatedFare);
      form.setValue("estimatedFare", data.estimatedFare);
    } catch (error) {
      console.error("Failed to calculate fare:", error);
    }
  };

  const serviceType = form.watch("serviceType");
  const weight = form.watch("weight");

  useEffect(() => {
    if (serviceType && weight) {
      calculateFare(serviceType, weight);
    }
  }, [serviceType, weight]);

  const onSubmit = (data: InsertBooking) => {
    createBookingMutation.mutate(data);
  };

  return (
    <section id="booking" className="py-20 bg-gradient-to-br from-gray-100 to-gray-200">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Book Your Cargo Service</h2>
          <p className="text-xl text-gray-600">Get instant fare estimates and book your transportation</p>
        </div>

        <div className="bg-white rounded-2xl shadow-xl p-8">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="pickupLocation"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="flex items-center text-sm font-semibold text-gray-700">
                        <MapPin className="h-4 w-4 text-primary mr-2" />
                        Pickup Location
                      </FormLabel>
                      <FormControl>
                        <Input placeholder="Enter pickup address" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="deliveryLocation"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="flex items-center text-sm font-semibold text-gray-700">
                        <MapPin className="h-4 w-4 text-secondary mr-2" />
                        Delivery Location
                      </FormLabel>
                      <FormControl>
                        <Input placeholder="Enter delivery address" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="pickupDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="flex items-center text-sm font-semibold text-gray-700">
                        <Calendar className="h-4 w-4 text-primary mr-2" />
                        Pickup Date
                      </FormLabel>
                      <FormControl>
                        <Input type="date" min={new Date().toISOString().split('T')[0]} {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="pickupTime"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="flex items-center text-sm font-semibold text-gray-700">
                        <Clock className="h-4 w-4 text-primary mr-2" />
                        Pickup Time
                      </FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select time" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="morning">Morning (6 AM - 12 PM)</SelectItem>
                          <SelectItem value="afternoon">Afternoon (12 PM - 6 PM)</SelectItem>
                          <SelectItem value="evening">Evening (6 PM - 10 PM)</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="serviceType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="flex items-center text-sm font-semibold text-gray-700">
                        <Truck className="h-4 w-4 text-primary mr-2" />
                        Service Type
                      </FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select service" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="mini">Mini Truck (Up to 3 tons)</SelectItem>
                          <SelectItem value="full">Full Truck (Up to 32 tons)</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="weight"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="flex items-center text-sm font-semibold text-gray-700">
                        <Weight className="h-4 w-4 text-primary mr-2" />
                        Estimated Weight (tons)
                      </FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          placeholder="Enter weight" 
                          step="0.1" 
                          min="0"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="cargoDescription"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="flex items-center text-sm font-semibold text-gray-700">
                      <Package className="h-4 w-4 text-primary mr-2" />
                      Cargo Description
                    </FormLabel>
                    <FormControl>
                      <Textarea 
                        rows={3} 
                        placeholder="Describe your cargo (type, special handling requirements, etc.)" 
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Fare Display */}
              <div className="bg-gray-50 rounded-xl p-6 border-2 border-dashed border-gray-300">
                <div className="text-center">
                  <h3 className="text-lg font-semibold text-gray-700 mb-2">Estimated Fare</h3>
                  <div className="text-3xl font-bold text-primary mb-2">₹{estimatedFare}</div>
                  <p className="text-sm text-gray-600">Final price may vary based on actual distance and route</p>
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="contactName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="flex items-center text-sm font-semibold text-gray-700">
                        <User className="h-4 w-4 text-primary mr-2" />
                        Contact Name
                      </FormLabel>
                      <FormControl>
                        <Input placeholder="Your full name" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="contactPhone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="flex items-center text-sm font-semibold text-gray-700">
                        <Phone className="h-4 w-4 text-primary mr-2" />
                        Phone Number
                      </FormLabel>
                      <FormControl>
                        <Input type="tel" placeholder="Your phone number" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <Button 
                type="submit" 
                className="w-full bg-primary hover:bg-blue-700 text-white px-8 py-4 rounded-lg text-lg font-semibold"
                disabled={createBookingMutation.isPending}
              >
                <Send className="h-5 w-5 mr-2" />
                {createBookingMutation.isPending ? "Submitting..." : "Submit Booking Request"}
              </Button>
            </form>
          </Form>
        </div>
      </div>
    </section>
  );
}
