import { Truck, Zap, Check } from "lucide-react";

export default function ServicesSection() {
  const serviceCities = [
    "Kolkata", "Howrah", "Durgapur", "Asansol", "Siliguri", "Malda",
    "Bankura", "Burdwan", "Jalpaiguri", "Krishnanagar", "Raiganj", "+ More Cities"
  ];

  return (
    <section id="services" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Our Services</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Professional cargo transportation solutions tailored to your needs across West Bengal
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12">
          {/* Full Truck Service */}
          <div className="bg-gray-50 rounded-2xl p-8 hover:shadow-xl transition-shadow">
            <img 
              src="https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400" 
              alt="Large cargo truck" 
              className="w-full h-64 object-cover rounded-xl mb-6" 
            />
            <div className="flex items-center mb-4">
              <Truck className="h-8 w-8 text-primary mr-4" />
              <h3 className="text-2xl font-bold text-gray-900">Full Truck Services</h3>
            </div>
            <p className="text-gray-600 mb-6">
              Heavy-duty trucks for large cargo loads. Perfect for industrial goods, bulk materials, and long-distance transportation across West Bengal.
            </p>
            <ul className="space-y-3 mb-6">
              <li className="flex items-center text-gray-700">
                <Check className="h-5 w-5 text-accent mr-3" />
                Capacity: Up to 32 tons
              </li>
              <li className="flex items-center text-gray-700">
                <Check className="h-5 w-5 text-accent mr-3" />
                GPS tracking included
              </li>
              <li className="flex items-center text-gray-700">
                <Check className="h-5 w-5 text-accent mr-3" />
                Insurance coverage
              </li>
              <li className="flex items-center text-gray-700">
                <Check className="h-5 w-5 text-accent mr-3" />
                Professional drivers
              </li>
            </ul>
            <div className="text-2xl font-bold text-primary mb-4">Starting from ₹15/km</div>
          </div>

          {/* Mini Truck Service */}
          <div className="bg-gray-50 rounded-2xl p-8 hover:shadow-xl transition-shadow">
            <img 
              src="https://images.unsplash.com/photo-1519003722824-194d4455a60c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400" 
              alt="Mini truck" 
              className="w-full h-64 object-cover rounded-xl mb-6" 
            />
            <div className="flex items-center mb-4">
              <Zap className="h-8 w-8 text-secondary mr-4" />
              <h3 className="text-2xl font-bold text-gray-900">Mini Truck Services</h3>
            </div>
            <p className="text-gray-600 mb-6">
              Compact and efficient mini trucks for smaller loads and local deliveries. Ideal for city transport and quick deliveries.
            </p>
            <ul className="space-y-3 mb-6">
              <li className="flex items-center text-gray-700">
                <Check className="h-5 w-5 text-accent mr-3" />
                Capacity: Up to 3 tons
              </li>
              <li className="flex items-center text-gray-700">
                <Check className="h-5 w-5 text-accent mr-3" />
                Quick city deliveries
              </li>
              <li className="flex items-center text-gray-700">
                <Check className="h-5 w-5 text-accent mr-3" />
                Fuel efficient
              </li>
              <li className="flex items-center text-gray-700">
                <Check className="h-5 w-5 text-accent mr-3" />
                Same day service
              </li>
            </ul>
            <div className="text-2xl font-bold text-secondary mb-4">Starting from ₹8/km</div>
          </div>
        </div>

        {/* Service Areas */}
        <div className="mt-16 text-center">
          <h3 className="text-2xl font-bold text-gray-900 mb-8">Service Coverage Areas in West Bengal</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {serviceCities.map((city, index) => (
              <div key={index} className="bg-primary text-white px-4 py-2 rounded-lg text-sm font-medium">
                {city}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
